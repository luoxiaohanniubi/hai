<?php
Route::get('show','UserController@User');
Route::post('click','UserController@click');
Route::get('user','UserController@Show');
Route::post('Add','UserController@Add');
Route::post('button','UserController@button');
Route::post('update','UserController@update');
Route::post('delete','UserController@delete');
Route::get('upda','UserController@upda');
// 下面是项目
Route::get('indexshow','index\IndexController@LndexShow');
Route::get('writeaddrshow','index\IndexController@writeaddrshow');
Route::post('writeaddradd','index\IndexController@writeaddradd');
Route::get('loginshow','index\IndexController@LoginShow');
Route::get('registershow','index\IndexController@RegisterShow');
Route::get('allshops','index\IndexController@allshops');
Route::get('address','index\IndexController@address');
Route::get('shopcontent','index\IndexController@shopcontent');
Route::get('t1','index\IndexController@t1');
Route::get('arr','index\IndexController@arr');
Route::post('writeaddrupd','index\IndexController@writeaddrupd');
Route::post('telcode','index\IndexController@TelCode');
Route::post('addressupdate','index\IndexController@addressupdate');
Route::get('addressupd','index\IndexController@addressupd');
Route::post('addressdel','index\IndexController@addressdel');
Route::post('btnPay','index\IndexController@btnPay');
Route::get('shopcart','index\IndexController@shopcart');
Route::get('payment','index\IndexController@paymentshow');
Route::post('cart','index\IndexController@cart');
Route::post('cartdel','index\IndexController@cartdel');
Route::post('cartdelete','index\IndexController@cartdelete');
Route::post('addli','index\IndexController@addli');
Route::post('t','index\IndexController@t');
Route::post('j','index\IndexController@j');
Route::post('category','index\IndexController@category');
Route::post('RegisterAdd','index\IndexController@RegisterAdd');
Route::post('loginadd','index\IndexController@LoginAdd');
Route::get('info','index\IndexController@info');
Route::post('payment','index\IndexController@payment');
Route::any('userpage','index\IndexController@userpage');

// Route::get('user/{id}',function($id){
// 	if($id<5){
// 		return redirect("https://www.baidu.com");
// 	}else{
// 		return view('show');
// 	}
// Route::get('add',"UserController@User")
// });

// Route::prefix('admin')->group(function () {
//     Route::get('users', function () {
//         echo '刘沁茹';
//     });
// });