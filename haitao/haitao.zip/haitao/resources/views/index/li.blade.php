 @foreach ($data as $key=>$val)
    <li id="23468">    
        <span class="gList_l fl">        
            <img class="lazy" data-original="{{$val->goods_img}}" src="{{$val->goods_img}}">
        </span>    
        <div class="gList_r">        
            <h3 class="gray6">
                <a href="/shopcontent?goods_id={{$val->goods_id}}">     
                    <h3 class="gray6">
                        {{$val->goods_name}}
                    </h3>   
                </a>    </h3>        
            <em class="gray9">价值：￥{{$val->self_price}}</em>
            <div class="gRate">            
                <div class="Progress-bar">    
                    <p class="u-progress">
                        <span style="width:{{$val->goods_num/15}}%;" class="pgbar">
                            <span class="pging"></span>
                        </span>
                    </p>                
                    <ul class="Pro-bar-li">
                        <li class="P-bar01"><em>{{$val->goods_num}}</em>已参与</li>
                        <li class="P-bar02"><em>{{$val->goods_score}}</em>总需人次</li>
                        <li class="P-bar03"><em>{{$val->market_price}}</em>剩余</li>
                    </ul>            
                </div>           
                <a codeid="12785750" class="" canbuy="646"><s></s></a>        
            </div>    
        </div>
    </li>
@endforeach