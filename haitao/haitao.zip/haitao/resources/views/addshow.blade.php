<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>

</head>
<style>
    .a li{
        float:left;
        list-style:none;
        margin-left:30px;
    }
</style>
<body>
	<div id="div">
		<form id="form" >
				<table border="1">
					<select name="com_is" id="com_is">
						<option value="">--请选择--</option>
						<option value="1">上架</option>
						<option value="2">下架</option>
					</select>
					<select name="pay_is" id="pay_is">
						<option value="">--请选择--</option>
						<option value="1">热卖</option>
						<option value="2">冷卖</option>
					</select>
					<input type="button" value="搜索" id="button">
					<tr>
						<td>ID</td>
						<td>名称</td>
						<td>分类</td>
						<td>描述</td>
						<td>是否热卖</td>
						<td>是否上架</td>
						<td>操作</td>
					</tr>
					<?php foreach($data as $key=>$val){?>
					<tr>
						<td class="click"><?php echo $val->com_id ?></td>
						<td class="click">
							 <p class="name">{{ $val->com_name }}</p>
							<input type="text" id="{{$val->com_id}}" class="input" style="display:none">
						</td>
						<td>{{ $val->id }}</td>
						<td>{{ $val->com_text }}</td>
						<td>
							@if($val->pay_is==1)
							<p>热卖</p>
							@else
							<p>冷卖</p>
							@endif
						</td>
						<td>
							@if($val->com_is==1)
							<p>上架</p>
							@else
							<p>下架</p>
							@endif
						</td>
						<td>
							<input id="id" type="hidden" value="{{ $val->com_id }}">
							<a href="#" id='del' >删除</a>
							<a href="upda?id={{ $val->com_id }}" >修改</a>
						</td>
					</tr>
					<?php } ?>
				</table>
				<div class="a">
					{{ $data->links() }}
				</div>
			</form>
	</div>
	
</body>
</html>
<script src="/js/jquery-3.2.1.min.js"></script>
<script language="javascript" type="text/javascript">
		$(function () {
			 
			//删除
			$(document).on('click','#del',function(){
				var data={};
				var id = $(this).prev().val();
				data.id = id;
				$.ajax({
					method:"POST",
					url:"delete",
					data:data,
					// dataType :"json",
					success:function(msg){
						if(msg==1){
							alert('删除成功');
							parent.location.href='/user';
						}else{
							alert('删除失败');
							parent.location.href='/user';
						}
					}
				});
			});

			//及点及改
			$('.name').click(function(){
				var _this = $(this);
				_this.hide();
				_this.next().show();
				var text = _this.text();
				_this.next().val(text);
			});
			$('.input').blur(function(){
				var _this = $(this);
				var text=_this.prev().text();
				var val = _this.val();
				var id = _this.attr('id');
				if(val!=text){
				var data={};
			    data.val=val;
			    data.id=id;
				$.ajax({
					url:"click",
					method:"POST",
					data:data,
					success:function(msg){
						_this.hide();
						_this.prev().text(msg);
						_this.prev().show();
					}
				})
				}else{
					_this.hide();
					_this.prev().show();
				}
			})

			//搜索
			$('#button').click(function(){
				var data = {};
				var com_is=$('#com_is').val();
				var pay_is=$('#pay_is').val();
				data.com_is = com_is;
				data.pay_is = pay_is;
				$.ajax({
					method:"POST",
					url:"button",
					data:data,
					success:function(msg){
						console.log(msg);
						$('#div').html(msg);
					}
				});
			})
		})
</script>
<!-- 点一下
出文本框

失去焦点
失去文本框
保存，更改

