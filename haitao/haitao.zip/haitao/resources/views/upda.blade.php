<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
董波钊
<!-- <?php print_r($data) ?> -->
</head>
<body>
	<form id="form" >
		<table border="1">
			<input type="hidden" value="{{$info->com_id}}" name="com_id">
			<tr>
				<td>名称</td>
				<td><input type="text" value="{{ $info->com_name??'' }}" name="com_name"></td>
			</tr>
			<tr>
				<td>分类</td>
				<td>
					<select  name="id">
						@foreach ($data as $key=>$val)
						@if($data['0']->id == $val->id)

							<option value="<?php echo $val->name ?>" selected><?php echo $val->name ?></option>
							@else
							<option value="<?php echo $val->name ?>"><?php echo $val->name ?></option>
							@endif
							@endforeach
					</select>
				</td>
			</tr>
			<tr>
				<td>描述</td>
				<td><textarea name="com_text"  cols="30" rows="10">{{ $info->com_text ??''}}</textarea></td>
			</tr>
			<tr>
				<td>是否展示</td>
				<td>
					@if ($info!='')
						@if ($info->com_is==1)
						 是<input name="com_is" value="1" type="radio" checked>
						 否<input name="com_is" value="2" type="radio">
						 @else
						 是<input name="com_is" value="1" type="radio">
						 否<input name="com_is" value="2" type="radio" checked>
						 @endif
					@else
						 是<input name="com_is" value="1" type="radio">
						 否<input name="com_is" value="2" type="radio" checked>
					@endif
					
				</td>
			</tr>
			<tr>
				<td>是否上架</td>
				<td>
					@if ($info!='')
						@if ($info->pay_is==1)
						 是<input name="pay_is" value="1" type="radio" checked>
						 否<input name="pay_is" value="2" type="radio">
						 @else
						 是<input name="pay_is" value="1" type="radio">
						 否<input name="pay_is" value="2" type="radio" checked>
						 @endif
					@else
						 是<input name="com_is" value="1" type="radio">
						 否<input name="com_is" value="2" type="radio" checked>
					@endif
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="button" value="确定" id="sub"></td>
			</tr>
		</table>
	</form>
</body>
</html>
<script src="/js/jquery-3.2.1.min.js"></script>
<script>
		$('#sub').click(function(){
			var data = $('#form').serialize();
			$.ajax({
				url:"update",
				method:"POST",
				data:data,
			}).done(function(msg){
				console.log(msg);
				if(msg==1){
					alert('修改成功');
					parent.location.href='/user';
				}else{
					alert('修改失败');
					parent.location.href='/show';
				}
			});
		});
</script>
