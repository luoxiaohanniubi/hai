<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use Illuminate\Support\Facades\DB;

class UserController extends Controller
{
	//下拉菜单
    public function User(){
    	$data = DB::select('select * from fenlei');
    	// $user=DB::table('fenlei')->get();
    	return view('show',['data'=>$data]);
    }

    //添加
    public function Add(Request $request){
    	$data=$request->input();
    	$user = DB::table("com")->insert($data);
    	if($user){
    		return 1;
    	}else{
    		return 2;
    	}
    }

    //展示
    public function Show(){
    	// $data = DB::select('select * from fenlei');
    	$data = DB::table('com')->paginate(3);
    	return view('Addshow',['data'=>$data]);
    }

    //删除
    public function delete(Request $request){
    	$arr = $request->input();
    	$id = $arr['id'];
    	$where=['com_id'=>$id];
    	$data = DB::table('com')->where($where)->delete();
    	if($data){
    		return 1;
    	}else{
    		return 2;
    	}
    }

    //修改展示
    public function upda(Request $request){
    	$id = $request->input('id');
    	$where=['com_id'=>$id];
    	$info = DB::table('com')->where($where)->first();
    	$data = DB::select('select * from fenlei');
    	return view('upda',['info'=>$info,'data'=>$data]);
    }

    //执行修改
    public function update(Request $request){
    	$data = $request->input();
    	$where=[
    		'com_id'=>$data['com_id'],
    	];
    	$info = DB::table('com')->where($where)->update($data);
    	if($data){
    		return 1;
    	}else{
    		return 2;
    	}
    	//return $data;
    }

    //及点及改
    public function click(Request $request){
    	$info=$request->input();
    	$com_name = $info['val'];
    	$id = $info['id'];
		$where=['com_id'=>$id];
		$data=DB::table('com')->where($where)->update(['com_name'=>$com_name]);
		if($data){
			return $com_name;
		}else{
			return 2;
		}
    }

    //多条件搜索
    public function button(Request $request){
    	$info=$request->input();
    	$where=[];
    	if(empty($info['com_is'])&&empty($info['pay_is'])){
    		$where=['com_is'=>$info['com_is'],'pay_is'=>$info['pay_is']];
    	}else if(empty($info['com_is'])&&!empty($info['pay_is'])){
    		$where=['pay_is'=>$info['pay_is']];
    	}else if(!empty(['com_is'])&&empty($info['pay_is'])){
    		$where=['com_is'=>$info['com_is']];
    	}
    	//print_r($where);
    	$data = DB::table('com')->where($where)->paginate(3);
    	// print_r($data);
    	return view('Addshow',['data'=>$data]);

    }
}
