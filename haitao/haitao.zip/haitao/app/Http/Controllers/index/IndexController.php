<?php

namespace App\Http\Controllers\index;

use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

use App\Http\Controllers\Controller;

use App\extend\send\Send;

use App\models\Cart;

class IndexController extends Controller
{
	protected static $arrCate;

	//我的潮购
	public function userpage(){
		return view('index.userpage');
	}

	public function writeaddrupd(Request $request){
		$arr = $request->input();
		$id=$arr['id'];
		$data['consignee_name']=$arr['consignee_name'];
		$data['consignee_tel']=$arr['consignee_tel'];
		$data['province']=$arr['province'];
		$data['detailed_address']=$arr['detailed_address'];
		$info = DB::table('order_address')->where('id',$id)->update($data);
		if($info){
			$arr=array('status'=>1,'msg'=>'Yes');
			return $arr;
		}else{
			$arr=array('status'=>0,'msg'=>'No');
			return $arr;
		}
	}

	//修改地址展示
	public function addressupd(Request $request){
		$id = $request->input('id');
		$data = DB::table('order_address')->where('id',$id)->get();
		return view('index.addressupd',['data'=>$data]);
	}
	//地址删除
	public function addressdel(Request $request){
		$user_id=session('id');
		if(empty($user_id)){
			$arr=array('status'=>0,'msg'=>'请先登录!');
			return $arr;
		}
		$id = $request->input('id');
		$data = DB::table('order_address')->where('id',$id)->delete();
		if($data){
			$arr=array('status'=>1,'msg'=>'Yes^_^!');
			return $arr;
		}else{
			$arr=array('status'=>0,'msg'=>'No o(╥﹏╥)o');
			return $arr;
		}
	}

	//地址添加
	public function writeaddradd(Request $request){
		$arr = $request->input();
		$user_id=session('id');
		$order_id=session('order_id');
		if(empty($user_id)){
			$arr=array('status'=>0,'msg'=>'请先登录!');
			return $arr;
		}
		if(empty($order_id)){
			$arr=array('status'=>0,'msg'=>'没有order_id!');
			return $arr;
		}
		$arr['ctime']=time();
		$arr['user_id']=$user_id;
		$arr['order_id']=$order_id;
		$arr['status']=0;
		$data = DB::table('order_address')->insert($arr);
		if($data){
			$arr=array('status'=>1,'msg'=>'Yes ^_^加入成功!');
			return $arr;
		}else{
			$arr=array('status'=>1,'msg'=>'No o(╥﹏╥)o');
			return $arr;
		}
	}

	//添加收货地址
	public function writeaddrshow(){
		return view('index.writeaddr');
	}

	//设置收货地址默认
	public function addressupdate(Request $request){
		$id=$request->input('id');
		$user_id=session('id');
		if(empty($user_id)){
			echo '请先登录';die;
		}
		$data = DB::table('order_address')->where('id',$id)->update(['status'=>1]);
		DB::table('order_address')->where('id','!=',$id)->update(['status'=>0]);

		if($data){
			$arr=array('status'=>1,'msg'=>'Yes ^_^!');
			return $arr;
		}else{
			$arr=array('status'=>0,'msg'=>'No o(╥﹏╥)o请联系客服哟！');
			return $arr;
		}
	}

	//收货地址
	public function address(){
		$user_id=session('id');
		if(empty($user_id)){
			echo '请先登录';die;
		}
		$data = DB::table('order_address')->where('user_id',$user_id)->get();
		return view('index.address',['data'=>$data]);
	}

	//查询收货地址
	public function btnPay(Request $request){
		$user_id=session('id');
		if(empty($user_id)){
			echo '请先登录';die;
		}
		$address=DB::table('order_address')->where('user_id',$user_id)->where('status',1)->get();
		if(!empty($address[0]->user_id)){
			$arr=array('status'=>1,'msg'=>'');
			return $arr;
		}else{
			$addressdata=DB::table('order_address')->where('user_id',$user_id)->get();
			if($addressdata){
				$arr=array('status'=>2,'msg'=>'^_^! 亲去设置收货地址吧');
				return $arr;
			}else{
				$arr=array('status'=>3,'msg'=>'亲! 还没有收货地址哦^_^!');
				return $arr;
			}
			
		}
	}

	//订单页面展示
	public function paymentshow(){
		$user_id=session('id');
		if(empty($user_id)){
			echo '请先登录';
		}
		$orderdata=DB::table('order_detail')->where('user_id',$user_id)->get();
		$order=DB::table('order')->where('user_id',$user_id)->where('pay_type',1)->select('order_amount')->get();
		$int=$order[0]->order_amount;
		return view('index.payment',['orderdata'=>$orderdata,'int'=>$int]);
	}
	//生成订单
	public function payment(Request $request){
		if(empty(session('user_tel'))){
			$arr = array(
				'status' => 0,
				'msg'	=>	'清先登录'
			);
			return $arr;
		}
		$id = $request->input('id');
		if(empty($id)){
			$arr = array('status'=>0,'msg'=>'请选择商品');
			return $arr;
		}
		$array=Cart::join('goods','goods.goods_id','=','cart.goods_id')->whereIn('cart.id',$id)->get()->toArray();
		$name=[];
		$num=[];
		foreach ($array as $key => $value) {
			if($value['num']>$value['goods_num']){
				$name[]=$value['goods_name'];
			}
			if($value['is_sell']!=1){
				$num[]=$value['goods_name'];
			}
		}

		$name=implode(',',$name);
		$num=implode(',',$num);
		if($name!=''){
			$arr = array('status'=>0,'msg'=>$name.'亲，您选择的商品库存不足哟！');
			return $arr;
		}
		if($num!=''){
			$arr = array('status'=>0,'msg'=>$name.'亲，暂无货物！');
			return $arr;
		}
		$self_price1 = $request->input('self_price');
		$self_price = ltrim($self_price1,'￥');
			$data = date('YmdHis',time()).rand(0,9);
			$user=session('id');
			$order=[
				'order_number'=>$data,
				'user_id'=>$user,
				'order_amount'=>$self_price,
				'ctime'=>time()
			];
			$orderdata=DB::table('order')->insert($order);
			if(!$orderdata){
				$arr = array('status'=>0,'msg'=>'订单表添加失败,系统错误');
				return $arr;
			}
			$order_id=DB::table('order')->where($order)->select('order_id')->get();
			foreach ($array as $key => $value) {
				$order_detail=[
					'user_id'=>$user,
					'order_id'=>$order_id[0]->order_id,
					'goods_id'=>$value['goods_id'],
					'goods_name'=>$value['goods_name'],
					'self_price'=>$value['self_price'],
					'goods_img'=>$value['goods_img'],
					'buy_number'=>$value['num'],
					'ctime'=>time()
				];
				DB::table('cart')->where(['id'=>$value['id']])->update(['status'=>1]);
				$order_detail=DB::table('order_detail')->insert($order_detail);
			}
				if($order_detail){
					session(['order_id'=>$order_id[0]->order_id]);
					$arr = array('status'=>1,'msg'=>$name.'添加成功');
					return $arr;
				}else{
					$arr = array('status'=>0,'msg'=>$name.'订单生成失败');
					return $arr;
				}
	}

	//库存修改
	public function j(Request $request){
		$val=$request->input();
		$int=$val['j'];
		$id=$val['id'];
		$where=['id'=>$id];
		$arr = DB::table('cart')->select('goods_num')->where($where)->get();
		$goods_num=$arr[0]->goods_num;
		$intval=intval($int);
		if($intval>$goods_num){
			$intval=$goods_num;
		}
		if($intval<=0){
			$intval=1;
		}
		$update=['num'=>$intval];
		$info = DB::table('cart')->where($where)->update($update);
		if($info){
			return 1;
		}else{
			return 2;
		}
	}
	
	//退出
	public function t(Request $request){
		$user=session("user_tel");
		if(empty($user)){
			$arr=array('status'=>0,'msg'=>'请先登录');
			return $arr;
		}else{
			if(!empty($user)){
				$user=session_unset("user_tel");
				if(empty($user)){
					$arr=array('status'=>1,'msg'=>'退出成功');
					return $arr;
				}else{
					$arr=array('status'=>0,'msg'=>'退出失败');
					return $arr;
				}
			}else{
				$arr=array('status'=>0,'msg'=>'退出失败');
				return $arr;
			}
		}
	}

	//购物车删除
	//多删
	public function cartdelete(Request $request){
		$array=$request->input('id');
		if(empty(session('user_tel'))){
			$arr=array(
					'status'=>0,
					'msg'=>'请登录'
				);
				return $arr;
		}else{
			foreach($array as $k=>$v) {
		    	$update=DB::table('cart')->where(['id'=>$v])->update(['status'=>1]);
			}
			if($update){
				$arr=array(
					'status'=>1,
					'msg'=>'删除成功'
				);
				return $arr;
			}else{
				$arr=array(
					'status'=>0,
					'msg'=>'删除失败'
				);
				return $arr;
			}
		}
		
	}

	//单删
	public function cartdel(Request $request){
		$id=$request->input('id');
		$update=DB::table('cart')->where(['id'=>$id])->update(['status'=>1]);
		if($update){
			$arr=array(
				'status'=>1,
				'msg'=>'删除成功'
			);
			return $arr;
		}else{
			$arr=array(
				'status'=>0,
				'msg'=>'删除失败'
			);
			return $arr;
		}
	}

	//加入购物车
	public function cart(Request $request){
		$goods_id=$request->input('goods_id');
		if(empty(session('id'))){
			$arr=array(
				'status'=>0,
				'msg'=>'请先登录',
			);
			return $arr;
		}
		$arr=DB::table('goods')->where(['goods_id'=>$goods_id])->get();
		if(empty($arr)){
			$arr=array(
				'status'=>0,
				'msg'=>'您选择的货物已下架！',
			);
			return $arr;
		}
		$user = session('user_tel');
		$user_id = DB::table('user')->where(['user_tel'=>$user])->select('user_id')->get();
		$data=[
			'goods_id'=>$arr['0']->goods_id,
			'user_id'=>$user_id[0]->user_id,
			'goods_name'=>$arr['0']->goods_name,
			'goods_img'=>$arr['0']->goods_img,
			'goods_num'=>$arr['0']->goods_num,
			'self_price'=>$arr['0']->self_price
		];
		
		

			$data_arr=DB::table('cart')->where(['goods_name'=>$data['goods_name']])->where(['user_id'=>$user_id[0]->user_id])->get();
			if(empty($data_arr[0]->goods_name)){
				$arr_cart=DB::table('cart')->insert($data);
				if($arr_cart){
					$arr=array(
						'status'=>1,
						'msg'=>'亲，加入成功快去看看吧',
					);
					return $arr;
				}else{
					$arr=array(
						'status'=>0,
						'msg'=>'商品已下架',
					);
					return $arr;
				}
			}else{
				$int=$data_arr[0]->num+1;
				$update=DB::table('cart')->where(['goods_name'=>$data['goods_name']])->update(['num'=>$int]);
				if($update){
					$arr=array(
						'status'=>1,
						'msg'=>'亲，加入成功快去看看吧',
					);
					return $arr;
				}else{
					$arr=array(
						'status'=>0,
						'msg'=>'商品已下架',
					);
					return $arr;
				}
			}
		
	}

	//购物车展示
	public function shopcart(){
		$arr=DB::table('goods')->paginate(4);
		$user=session("user_tel");
		if(empty($user)){
			echo '清先登录';
		}else{
			$data=DB::table('cart')->get();
			if(empty($data)){
					return view('index.shopcart',['arr'=>$arr]);
				}else{
					return view('index.shopcart',['data'=>$data,'arr'=>$arr]);
				}
			}
		}

	//详情页
	public function shopcontent(Request $return){
		$goods_id=$return->input();
		$data=DB::table('goods')->where('goods_id',$goods_id)->first();
		$str=$data->goods_imgs;
		$var=explode("|",$str);
		return view('index.shopcontent',['data'=>$data,'var'=>$var]);
	}

	//分类查询
	public function category(Request $return){
		$cate_id = $return->input('cate_id');
		$this->get($cate_id);
		$arr=array_filter(self::$arrCate);
		$data=DB::table('goods')->where('cate_id',$arr)->get();
		// print_r($data);die;
		return view('index.li',['data'=>$data]);
	}

	//商品分类
	public function allshops(){
		$arr = DB::table('category')->where(['pid'=>0])->get();
		$data = DB::table('goods')->get();
		return view('index/allshops',['goods'=>$arr,'data'=>$data]);
		
	}

	//流加载
	public function addli(Request $request){
		$arr=array();
		$page = $request->input('page',1);
		$pagNum=2;
		$offset=($page-1)*$pagNum;
		$arrDataInfo = DB::table('goods')->offset($offset)->limit($pagNum)->get();

		$totalData=DB::table("goods")->count();
		$pageTotal=ceil($totalData/$pagNum);
		$objview = view("index.goods",['data'=>$arrDataInfo]);
		$content = response($objview)->getContent();
		$data['info']=$content;
		$data['page']=$pageTotal;
		return $data;
	}

	//短信发送验证
	public function TelCode(Request $request){
        $obj = new Send();
		$arr=$request->input();
		$tel=$arr['userMobile'];
		if(empty($tel)){
			$error=array(
				'status'=>0,
				'msg'=>'手机号不可为空',
			);
			return $error;
		}
		$num = rand(1000,9999);
		$time=time()+60;
		$data['tel']=$tel;
    	$data['time']=$time;
    	$data['code']=$num;
    	$codedata = DB::table('enroll')->where(['tel'=>$data['tel'],'status'=>1])->first();
    	if(!empty($codedata)){
    		$error=array(
				'status'=>0,
				'msg'=>'您的手机号已注册',
			);
			return $error;
    	}
    	if($obj->show($data['tel'],$data['code'])!=100){
    		$error=array(
				'status'=>0,
				'msg'=>'系统错误',
			);
			return $error;
    	}
    	$telcode = DB::table('enroll')->insert($data);
    	if($telcode){
    		$error=array(
				'status'=>1,
				'msg'=>'短信发送成功',
			);
			return $error;
    	}else{
    		$error=array(
				'status'=>0,
				'msg'=>'短信发送失败',
			);
			return $error;
    	}
    }

    //首页展示
    public function LndexShow(){
    	$data=DB::table('goods')->get();
    	return view('index/Index',['data'=>$data]);
    }

    //登录页面
    public function LoginShow(){
    	return view('index/login');
    }
    //注册页面
    public function RegisterShow(){
    	return view('index/register');
    }

    //注册入库
    public function RegisterAdd(Request $request){
    	$arr = $request->input();
    	$code=$arr['code'];
    	if(empty($code)){
    		$error=array(
    			'status'=>0,
    			'msg'=>'验证码不可为空'
    		);
    		return $error;
    	}
    	// print_r($arr);die;
    	$codedata = DB::table('enroll')->where(['tel'=>$arr['userMobile']])->where(['code'=>$arr['code']])->first();

    	if($codedata){
	    	if($codedata->status==0){
				if(60<=time()-$codedata->time){
					$error=array(
		    			'status'=>0,
		    			'msg'=>'验证码不可用'
		    		);
		    		return $error;
				}else{
					if(empty($arr['pwd'])){
			    		$error = array(
			    			'status'=>0,
			    			'msg'=>"密码不可为空"
			    		);
			    		return $error;
			    	}

		    		if(empty($arr['conpwd'])){
			    		$error=array(
			    			'status'=>0,
			    			'msg'=>"确认密码不可为空"
			    		);
			    		return $error;
		    		}

		    		if($arr['pwd']!=$arr['conpwd']){
		    			$error=array(
			    			'status'=>0,
			    			'msg'=>"您的两次密码不一致！"
		    			);
		    			return $error;
		    		}

		    		$where=['user_tel'=>$arr['userMobile']];
		    		$user_tel = DB::table('user')->where($where)->first();
		    		if($user_tel){
						$error=array(
							'status'=>0,
							'msg'=>"您的手机号已注册"
						);
						return $error;
		    		}
		    		
		    		$user_tel = $arr['userMobile'];
		    		$pwd = $arr['pwd'];
		    		$user_pwd = md5($pwd);
		    		$insert=['user_tel'=>$user_tel,'user_pwd'=>$user_pwd];
		    		$info = DB::table('user')->insert($insert);
		    		if($info){
		    			DB::table('enroll')->where(['id'=>$codedata->id])->update(['status'=>1]);
		    			$win=array(
		    				'status'=>1,
		    				'msg'=>"注册成功"
		    			);
		    			return $win;
		    		}
				}	
			}else{
				$error=array(
	    			'status'=>0,
	    			'msg'=>'手机号或验证码错误o(╥﹏╥)o'
	    		);
	    		return $error;
			}
    	}else{
    		$error=array(
    			'status'=>0,
    			'msg'=>'手机号或验证码错误o(╥﹏╥)o'
    		);
    		return $error;
    	}
    }

    //跳转登录
    public function LoginAdd(Request $request){
    	$arr = $request->input();
    	$user_tel = $arr['tel'];
    	$pwd = $arr['pwd'];
    	$user_pwd=md5($pwd);
    	$where=['user_pwd'=>$user_pwd,'user_tel'=>$user_tel];
    	$data = DB::table('user')->where($where)->first();
    	if($data){
    		session(['id'=>$data->user_id,'user_tel'=>$user_tel]);
    		return 1;
    	}else{
    		return 2;
    	}
    }

    //递归循环
    private function get($id){
    	$cate=DB::table('category')->select('cate_id')->where('pid',$id)->get();
    	if(count($cate)!=0){
    		foreach($cate as $k=>$v){
	    		$cate_id=$v->cate_id;
	    		$id=$this->get($cate_id);
	    		self::$arrCate[]=$id;
    		}
    	}
    	if(count($cate)==0){
    		return $id;
    	}
    }
}
