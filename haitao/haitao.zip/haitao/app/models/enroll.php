<?php


namespace App\models;


use Illuminate\Database\Eloquent\Model;


class enroll extends Model
{
    protected $table="enroll";
}
