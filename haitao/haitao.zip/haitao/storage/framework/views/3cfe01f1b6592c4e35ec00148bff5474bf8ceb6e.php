 <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <li id="23468">    
        <span class="gList_l fl">        
            <img class="lazy" data-original="<?php echo e($val->goods_img); ?>" src="<?php echo e($val->goods_img); ?>">
        </span>    
        <div class="gList_r">        
            <h3 class="gray6">
                <a href="/shopcontent?goods_id=<?php echo e($val->goods_id); ?>">     
                    <h3 class="gray6">
                        <?php echo e($val->goods_name); ?>

                    </h3>   
                </a>    </h3>        
            <em class="gray9">价值：￥<?php echo e($val->self_price); ?></em>
            <div class="gRate">            
                <div class="Progress-bar">    
                    <p class="u-progress">
                        <span style="width:<?php echo e($val->goods_num/15); ?>%;" class="pgbar">
                            <span class="pging"></span>
                        </span>
                    </p>                
                    <ul class="Pro-bar-li">
                        <li class="P-bar01"><em><?php echo e($val->goods_num); ?></em>已参与</li>
                        <li class="P-bar02"><em><?php echo e($val->goods_score); ?></em>总需人次</li>
                        <li class="P-bar03"><em><?php echo e($val->market_price); ?></em>剩余</li>
                    </ul>            
                </div>           
                <a codeid="12785750" class="" canbuy="646"><s></s></a>        
            </div>    
        </div>
    </li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>