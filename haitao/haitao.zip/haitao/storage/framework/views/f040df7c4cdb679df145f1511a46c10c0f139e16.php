<?php
	$arr=array(
		array("id"=>1,"name"=>"lisi","age"=>20),
		array("id"=>2,"name"=>"lisi","age"=>50),
		array("id"=>3,"name"=>"lisi","age"=>10),
		array("id"=>4,"name"=>"lisi","age"=>9),
		array("id"=>5,"name"=>"lisi","age"=>4),
	);
	foreach($arr as $k=>$v){
		print_r($v);
	}
?>