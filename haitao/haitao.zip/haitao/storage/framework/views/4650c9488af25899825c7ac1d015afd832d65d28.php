<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
董波钊
<!-- <?php print_r($data) ?> -->
</head>
<body>
	<form id="form" >
		<table border="1">
			<input type="hidden" value="<?php echo e($info->com_id); ?>" name="com_id">
			<tr>
				<td>名称</td>
				<td><input type="text" value="<?php echo e($info->com_name??''); ?>" name="com_name"></td>
			</tr>
			<tr>
				<td>分类</td>
				<td>
					<select  name="id">
						<?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($data['0']->id == $val->id): ?>

							<option value="<?php echo $val->name ?>" selected><?php echo $val->name ?></option>
							<?php else: ?>
							<option value="<?php echo $val->name ?>"><?php echo $val->name ?></option>
							<?php endif; ?>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
				</td>
			</tr>
			<tr>
				<td>描述</td>
				<td><textarea name="com_text"  cols="30" rows="10"><?php echo e($info->com_text ??''); ?></textarea></td>
			</tr>
			<tr>
				<td>是否展示</td>
				<td>
					<?php if($info!=''): ?>
						<?php if($info->com_is==1): ?>
						 是<input name="com_is" value="1" type="radio" checked>
						 否<input name="com_is" value="2" type="radio">
						 <?php else: ?>
						 是<input name="com_is" value="1" type="radio">
						 否<input name="com_is" value="2" type="radio" checked>
						 <?php endif; ?>
					<?php else: ?>
						 是<input name="com_is" value="1" type="radio">
						 否<input name="com_is" value="2" type="radio" checked>
					<?php endif; ?>
					
				</td>
			</tr>
			<tr>
				<td>是否上架</td>
				<td>
					<?php if($info!=''): ?>
						<?php if($info->pay_is==1): ?>
						 是<input name="pay_is" value="1" type="radio" checked>
						 否<input name="pay_is" value="2" type="radio">
						 <?php else: ?>
						 是<input name="pay_is" value="1" type="radio">
						 否<input name="pay_is" value="2" type="radio" checked>
						 <?php endif; ?>
					<?php else: ?>
						 是<input name="com_is" value="1" type="radio">
						 否<input name="com_is" value="2" type="radio" checked>
					<?php endif; ?>
					
				</td>
			</tr>
			<tr>
				<td></td>
				<td><input type="button" value="确定" id="sub"></td>
			</tr>
		</table>
	</form>
</body>
</html>
<script src="/js/jquery-3.2.1.min.js"></script>
<script>
		$('#sub').click(function(){
			var data = $('#form').serialize();
			$.ajax({
				url:"update",
				method:"POST",
				data:data,
			}).done(function(msg){
				console.log(msg);
				if(msg==1){
					alert('修改成功');
					parent.location.href='/user';
				}else{
					alert('修改失败');
					parent.location.href='/show';
				}
			});
		});
</script>
